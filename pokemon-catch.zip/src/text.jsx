import styled from "@emotion/styled";

export const P = styled.p`
  color: #121212;
`;
